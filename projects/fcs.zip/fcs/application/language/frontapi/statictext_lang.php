<?php	 			
$lang['SUCESS_STATUS']	    			= 	1;
$lang['SUCESS_MESSAGE']	    			= 	"Successfully fetched data";
$lang['ERROR_STATUS']	    			= 	0;
$lang['ERROR_MESSAGE']	    			= 	"Data not found";
$lang['CITY_NOTFOUND']	    			= 	"City not found";



$lang['PHONE_EMPTY']	    			= 	"Phone no is empty";
$lang['USERTYPE_EMPTY']	    			= 	"User type is empty";
$lang['OTP_EMPTY']	    				= 	"OTP is empty";
$lang['ZONEID_EMPTY']	    			= 	"Zone Id is empty";
$lang['DATE_EMPTY']	    				= 	"Date is empty";
$lang['CATEID_EMPTY']	    			= 	"Category Id is empty";
$lang['CATEID_INCORRECT']	    		= 	"Category Id is empty";
$lang['SHOPID_EMPTY']	    			= 	"Shop Id is empty";
$lang['GRADETYPE_EMPTY']	    		= 	"Grade type is empty";
$lang['ORDERDATA_EMPTY']	    		= 	"Order data is empty";

$lang['PHONE_INCORRECT']	    		= 	"Phone no is incorrect";
$lang['OTP_INCORRECT']	    			= 	"OTP is incorrect";
$lang['OTP_INCORRECT']	    			= 	"OTP is incorrect";


$lang['INVALID_APIKEY']	    			= 	"Invalid API key";


$lang['SEND_OTP_TO_RMN']	    		= 	"OTP has been sent to your register mobile number.";
$lang['LOGIN_SUCCESSFULLY']	    		= 	"You have successfully login.";

$lang['SUCESS_PLACEORDER']	    		= 	"You order is successfully placed.";

$lang['ADD_TO_ORDER_SUCCESS']	    	= 	"Added to cart.";
$lang['UPDATE_TO_ORDER_SUCCESS']	    = 	"Update to cart.";
$lang['REMOVE_FROM_ORDER_SUCCESS']	    = 	"Removed from cart.";


