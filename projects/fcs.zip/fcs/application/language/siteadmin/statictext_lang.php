<?php	 	
$lang['invalidpassword']	            			= 	'Log failed. Password do not match';
$lang['invalidlogindetails']            			= 	"You have entered an invalid username or password";
$lang['emailnotavailable']            				= 	"This email id is not available.";
$lang['accountblock']            					= 	"You account is blocked. Please contact to administration.";

////////////////////////    alert mesaage  //////////
$lang['addsuccess']									=	'Data added successfully.';
$lang['updatesuccess']								=	'Data updated successfully.';
$lang['deletesuccess']								=	'Data deleted successfully.';
$lang['multipledeletesuccess']						=	'Miltiple data deleted successfully.';

$lang['addwarning']									=	'Data not add successfully.';
$lang['updatewarning']								=	'Data not update successfully.';
$lang['deletewarning']								=	'Data not delete successfully.';

$lang['adderror']									=	'Data not add successfully.';
$lang['updateerror']								=	'Data not update successfully.';
$lang['deleteerror']								=	'Data not delete successfully.';

$lang['accessdenied']								=	'You are not able to access this page.';
$lang['accessstatusdenied']							=	'You are not able to change status.';
$lang['accessdeletedenied']							=	'You are not able to delete data.';
$lang['notabletologin']								=	'You are not able to login in admin section.';

$lang['PERERROR']									=	'Please give atlist permission for one module.';

$lang['PHONEERROR']									=	'Please enter correct number.';
$lang['dateerror']								=	'End date should be greater then or equal to Start date.';
$lang['datecurrenterror']								=	'End date or Start date can not be greter then current date.';
